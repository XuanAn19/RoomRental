import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  require_cjs
} from "./chunk-J5AH7WSA.js";
import "./chunk-HOWG5LT4.js";
export default require_cjs();
//# sourceMappingURL=rxjs.js.map
